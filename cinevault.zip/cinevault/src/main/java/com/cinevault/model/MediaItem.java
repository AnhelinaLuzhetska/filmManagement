package com.cinevault.model;

import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public class MediaItem {

    public enum MediaType { FILM, TV_SERIES }
    public enum WatchStatus { SEEN, MUST_SEE }
   
    
    private final StringProperty id = new SimpleStringProperty();
    private final ObjectProperty<MediaType> mediaType = new SimpleObjectProperty<>();
    private final StringProperty title = new SimpleStringProperty();
    private final StringProperty description = new SimpleStringProperty();
    private final StringProperty photoPath = new SimpleStringProperty();
    private final ObjectProperty<WatchStatus> watchStatus = new SimpleObjectProperty<>();
    private final ObservableList<Genre> genres = FXCollections.observableArrayList();
    private final ObservableList<String> subGenres = FXCollections.observableArrayList();
    private final ObservableList<String> vibes = FXCollections.observableArrayList();

    // Se VISTO
    
    private final DoubleProperty rating = new SimpleDoubleProperty(0);
    private final StringProperty review = new SimpleStringProperty();

    // Se NON VISTO
    
    private final StringProperty personalNote = new SimpleStringProperty();

    // Metadata
    
    private final ObjectProperty<LocalDate> addedDate = new SimpleObjectProperty<>();

    public MediaItem() {
    	
        this.id.set(UUID.randomUUID().toString());
        this.addedDate.set(LocalDate.now());
        this.watchStatus.set(WatchStatus.MUST_SEE);
        this.mediaType.set(MediaType.FILM);
    }

    public MediaItem(String title, MediaType type) {
    	
        this();
        this.title.set(title);
        this.mediaType.set(type);
    }

    //  ID 
    
    public String getId() { 
    	
    	return id.get();
    }
    
    public StringProperty idProperty() { 
    	
    	return id; 
    }

    //  MediaType 
    
    public MediaType getMediaType() {
    	
    	return mediaType.get(); 
    }
    
    public void setMediaType(MediaType t) { 
    	
    	mediaType.set(t); 
    }
    
    public ObjectProperty<MediaType> mediaTypeProperty() { 
    	
    	return mediaType; 
    }

    // -Title
    
    public String getTitle() { 
    	
    	return title.get(); 
    	
    }
    
    public void setTitle(String t) { 
    	
    	title.set(t); 
    }
    
    public StringProperty titleProperty() { 
    	
    	return title; 
    }

    // Description 
    public String getDescription() { 
    	
    	return description.get(); 
    }
    
    public void setDescription(String d) { 
    	
    	description.set(d); 
    }
    
    public StringProperty descriptionProperty() { 
    	
    	return description; 
    }

    // Photo
    
    public String getPhotoPath() { 
    	
    	return photoPath.get();
    }
    
    public void setPhotoPath(String p) { 
    	
    	photoPath.set(p); 
    }
    
    public StringProperty photoPathProperty() { 
    	
    	return photoPath; 
    }

    // WatchStatus
    
    public WatchStatus getWatchStatus() { 
    	
    	return watchStatus.get(); 
    }
    
    public void setWatchStatus(WatchStatus s) { 
    	
    	watchStatus.set(s); 
    	
    }
    
    public ObjectProperty<WatchStatus> watchStatusProperty() {
    	
    	return watchStatus; 
    	
    }

    // Genre
    
    public ObservableList<Genre> getGenres() {
    	
    	return genres; 
    }
    
    public void setGenres(List<Genre> g) {
    	
    	genres.setAll(g); 
    }

    // SubGenres 
    
    public ObservableList<String> getSubGenres() { 
    	
    	return subGenres; 
    }
    
    public void setSubGenres(List<String> sg) { 
    	
    	subGenres.setAll(sg); 
    }

    // Vibes 
    public ObservableList<String> getVibes() {
    	
    	return vibes; 
    }
    
    public void setVibes(List<String> v) { 
    	
    	vibes.setAll(v);
    }

    //  Rating 
    
    public double getRating() {
    	
    	return rating.get(); 
    }
    
    public void setRating(double r) {
    	
    	rating.set(r); 
    }
   
    public DoubleProperty ratingProperty() {
    	
    	return rating; 
    }

    //  Review 
    
    public String getReview() { 
    	
    	return review.get(); 
    }
    
    public void setReview(String r) { 
    	
    	review.set(r);
    }
    
    public StringProperty reviewProperty() {
    	
    	return review; 
    }

    // Personal Note 
    public String getPersonalNote() {
    	
    	return personalNote.get(); 
    }
    
    public void setPersonalNote(String n) {
    	
    	personalNote.set(n); 
    }
    
    public StringProperty personalNoteProperty() { 
    	
    	return personalNote; 
    }

  
 //  Added Date
    
    public LocalDate getAddedDate() { 
    	
    	return addedDate.get();
    	
    }
    
    public void setAddedDate(LocalDate d) { 
    	
    	addedDate.set(d); 
    }
    
    public ObjectProperty<LocalDate> addedDateProperty() {
    	
    	return addedDate; 
    }

    public String getPrimaryGenreColor() {
    	
        if (genres.isEmpty()) {
        	
        	return "#1a1a2e";
        }
        
        return genres.get(0).getColor();
    }

    public String getGradientStyle() {
    	
        if (genres.isEmpty()) {
        	
        	return "-fx-background-color: #1a1a2e;";
        }
        
        if (genres.size() == 1) {
        	
            String c = genres.get(0).getColor();
            
            return String.format("-fx-background-color: linear-gradient(to bottom, %s22, #0B0B0E);", c);
        }
        
        String c1 = genres.get(0).getColor();
        String c2 = genres.get(1).getColor();
        return String.format("-fx-background-color: linear-gradient(to bottom right, %s33, %s22, #0B0B0E);", c1, c2);
    }

    public String getBorderGlowStyle() {
    	
        if (genres.isEmpty()) {
        	
        	return "-fx-border-color: #333;";
        }
        
        String c = genres.get(0).getColor();
        return String.format("-fx-border-color: %s; -fx-effect: dropshadow(gaussian, %s, 10, 0.4, 0, 0);", c, c);
    }
}
