package com.cinevault.model;

import java.util.HashSet;
import java.util.Set;

public class FilterCriteria {

    private MediaItem.WatchStatus watchStatus = null; // null = tutti
    private Set<Genre> genres = new HashSet<>();
    private Set<String> subGenres = new HashSet<>();
    private Set<String> vibes = new HashSet<>();
    private double minRating = 0.0;
    private MediaItem.MediaType mediaType = null; // null = tutti
    private String searchText = "";

    public FilterCriteria() {}

    public boolean matches(MediaItem item) {
    	
        if (watchStatus != null && item.getWatchStatus() != watchStatus) {
        	
        	return false;
        }
        
        if (mediaType != null && item.getMediaType() != mediaType) {
        	
        	return false;
        }
        
        if (!genres.isEmpty()) {
        	
            boolean hasAny = item.getGenres().stream().anyMatch(genres::contains);
         
            if (!hasAny) {
            	
            	return false;
            }
        }
        
        if (!subGenres.isEmpty()) {
        	
            boolean hasAny = item.getSubGenres().stream().anyMatch(subGenres::contains);
           
            if (!hasAny) {
            	
            	return false;
            }
        }
        
        if (!vibes.isEmpty()) {
        	
            boolean hasAny = item.getVibes().stream().anyMatch(vibes::contains);
           
            if (!hasAny) {
            	
            	return false;
            }
        }
        
        if (item.getWatchStatus() == MediaItem.WatchStatus.SEEN && item.getRating() < minRating) {
        	
        	return false;
        }
        
        if (searchText != null && !searchText.isBlank()) {
        	
            String lower = searchText.toLowerCase();
            String title = item.getTitle() == null ? "" : item.getTitle().toLowerCase();
           
            if (!title.contains(lower)) {
            	
            	return false;
            }
        }
        return true;
    }

    // Getters & Setters
    
    public MediaItem.WatchStatus getWatchStatus() { 
    	
    	return watchStatus;
    }
    
    public void setWatchStatus(MediaItem.WatchStatus watchStatus) { 
    	
    	this.watchStatus = watchStatus; 
    }

    public Set<Genre> getGenres() { 
    	
    	return genres; 
    }
    
    public void setGenres(Set<Genre> genres) { 
    	
    	this.genres = genres; 
    }

    public Set<String> getSubGenres() { 
    	
    	return subGenres; 
    }
    
    public void setSubGenres(Set<String> subGenres) { 
    	
    	this.subGenres = subGenres;
    }

    public Set<String> getVibes() { 
    	
    	return vibes;
    }
    
    public void setVibes(Set<String> vibes) { 
    	
    	this.vibes = vibes; 
    }

    public double getMinRating() { 
    	
    	return minRating; 
    }
    
    public void setMinRating(double minRating) { 
    	
    	this.minRating = minRating;
    }

    public MediaItem.MediaType getMediaType() { 
    	
    	return mediaType; 
    }
    
    public void setMediaType(MediaItem.MediaType mediaType) { 
    	
    	this.mediaType = mediaType; 
    }

    public String getSearchText() { 
    	
    	return searchText; 
    }
    
    public void setSearchText(String searchText) { 
    	
    	this.searchText = searchText; 
    }

    public void reset() {
    	
        watchStatus = null;
        mediaType = null;
        genres.clear();
        subGenres.clear();
        vibes.clear();
        minRating = 0.0;
        searchText = "";
    }

    public boolean isEmpty() {
    	
        return watchStatus == null && mediaType == null
                && genres.isEmpty() && subGenres.isEmpty()
                && vibes.isEmpty() && minRating == 0.0
                && (searchText == null || searchText.isBlank());
    }
}
