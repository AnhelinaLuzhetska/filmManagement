package com.cinevault.model;

import java.util.Arrays;
import java.util.List;

public enum Genre {
	
    ACTION("Action", "#FF2020", Arrays.asList(
            "martial arts", "superhero", "military", "spy action", "disaster action")),
   
    ADVENTURE("Adventure", "#FF8C00", Arrays.asList(
            "jungle adventure", "treasure hunt", "expedition", "survival adventure", "fantasy adventure")),
   
    COMEDY("Comedy", "#FFD700", Arrays.asList(
            "dark comedy", "satire", "parody", "romantic comedy", "absurd comedy", "cringe comedy")),
   
    DRAMA("Drama", "#1A3A6B", Arrays.asList(
            "family drama", "legal drama", "medical drama", "teen drama", "tragedy", "melodrama")),
   
    HORROR("Horror", "#111111", Arrays.asList(
            "psychological horror", "supernatural horror", "slasher", "body horror",
            "cosmic horror", "analog horror", "folk horror", "found footage", "survival horror", "creature feature")),
   
    THRILLER("Thriller", "#8B0000", Arrays.asList(
            "psychological thriller", "political thriller", "crime thriller", "techno-thriller", "erotic thriller")),
    
    MYSTERY("Mystery", "#6A0DAD", Arrays.asList(
            "detective mystery", "murder mystery", "conspiracy mystery", "supernatural mystery")),
    
    CRIME("Crime", "#3D3D3D", Arrays.asList(
            "mafia", "heist", "prison drama", "gangster", "detective crime")),
   
    ROMANCE("Romance", "#FF69B4", Arrays.asList(
            "enemies to lovers", "friends to lovers", "tragic romance", "paranormal romance", "slow burn")),
   
    SCI_FI("Sci-Fi", "#00CED1", Arrays.asList(
            "cyberpunk", "steampunk", "space opera", "time travel", "dystopian sci-fi", "alien invasion")),
   
    FANTASY("Fantasy", "#00A86B", Arrays.asList(
            "dark fantasy", "urban fantasy", "high fantasy", "mythological fantasy", "fairy tale fantasy")),
    
    APOCALYPSE("Apocalypse / Post-Apocalypse", "#8B7355", Arrays.asList(
            "zombie apocalypse", "nuclear apocalypse", "pandemic apocalypse", "survival apocalypse")),
  
    DYSTOPIAN("Dystopian", "#0047AB", Arrays.asList(
            "authoritarian dystopia", "technological dystopia", "social dystopia", "eco dystopia")),
   
    SURVIVAL("Survival", "#6B8E23", Arrays.asList(
            "wilderness survival", "disaster survival", "survival games", "psychological survival")),
   
    PSYCHOLOGICAL("Psychological", "#4B0082", Arrays.asList(
            "mind-bending", "existential", "paranoia", "unreliable narrator")),
   
    SLICE_OF_LIFE("Slice of Life", "#D2C9A3", Arrays.asList(
            "school life", "workplace", "coming-of-age", "daily life")),
   
    HISTORICAL("Historical", "#8B6914", Arrays.asList(
            "historical romance", "period drama", "historical war", "biographical historical")),
    
    WAR("War / Military", "#355E3B", Arrays.asList(
            "anti-war", "military strategy", "historical war", "resistance")),
   
    WESTERN("Western", "#C19A6B", Arrays.asList(
            "spaghetti western", "revisionist western", "modern western")),
    
    NOIR("Noir / Neo-Noir", "#36454F", Arrays.asList(
            "detective noir", "crime noir", "cyber noir", "neo-noir thriller")),
   
    MUSICAL("Musical", "#FFD700", Arrays.asList(
            "jukebox musical", "dance musical", "rock musical")),
   
    DOCUMENTARY("Documentary", "#E8E8E8", Arrays.asList(
            "true crime documentary", "nature documentary", "mockumentary", "investigative documentary")),
   
    ANIMATION("Animation", "#FF6EC7", Arrays.asList(
            "anime", "CGI", "stop-motion", "adult animation", "animated fantasy"));

    private final String displayName;
    private final String color;
    private final List<String> subGenres;

    Genre(String displayName, String color, List<String> subGenres) {
      
    	this.displayName = displayName;
        this.color = color;
        this.subGenres = subGenres;
    }

    public String getDisplayName() { 
    	
    	return displayName; 
    }
    
    public String getColor() { 
    	
    	return color; 
    }
    
    public List<String> getSubGenres() {
    	
    	return subGenres; 
    }

    @Override
    public String toString() { 
    	
    	return displayName;
    }
}
