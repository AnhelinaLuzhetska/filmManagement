package com.cinevault.model;

import java.util.Arrays;
import java.util.List;

public class Vibe {

    public static final List<String> ALL_VIBES = Arrays.asList(
            "cozy", "wholesome", "nostalgic", "dreamy", "magical", "hopeful", "romantic",
            "melancholic", "tragic", "depressing", "chaotic", "eerie", "disturbing", "unsettling",
            "suspenseful", "gritty", "raw", "campy", "surreal", "mind-bending", "cerebral",
            "liminal", "uncanny", "emotional", "comforting", "tense", "aggressive", "rebellious",
            "lonely", "existential", "cursed", "ethereal", "dark academia", "chaotic academia",
            "retro-futuristic", "vaporwave", "gothic", "industrial", "post-human", "fever dream",
            "soft apocalypse", "hopeless", "weirdcore", "dreamcore", "analog", "neon-noir",
            "divine horror", "cosmic dread"
    );

    private Vibe() {}
}
