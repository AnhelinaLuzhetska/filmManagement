package com.cinevault.data;

import com.cinevault.model.Genre;
import com.cinevault.model.MediaItem;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;

/**
 * Simple JSON-based persistence (no external libs required).
 * Saves to user home dir: ~/.cinevault/data.json
 */

public class DataStore {

    private static final String DIR = System.getProperty("user.home") + File.separator + ".cinevault";
    private static final String FILE = DIR + File.separator + "data.json";
    private static DataStore instance;
    private final ObservableList<MediaItem> items = FXCollections.observableArrayList(
            m -> new javafx.beans.Observable[]{ m.watchStatusProperty(), m.ratingProperty() });

    private DataStore() {
    	
        load();
    }

    public static DataStore getInstance() {
    	
        if (instance == null) {
        	
        	instance = new DataStore();
        }
        
        return instance;
    }

    public ObservableList<MediaItem> getItems() { 
    	
    	return items; 
    	
    }

    public void add(MediaItem item) {
    	
        items.add(item);
        save();
    }

    public void update(MediaItem item) {
    	
        save();
    }

    public void remove(MediaItem item) {
    	
        items.remove(item);
        save();
    }

    //Simple manual JSON serialization

    public void save() {
    	
        try {
        	
            Files.createDirectories(Paths.get(DIR));
            StringBuilder sb = new StringBuilder("[\n");
           
            for (int i = 0; i < items.size(); i++) {
                
            	sb.append(toJson(items.get(i)));
            	
                if (i < items.size() - 1) {
                	
                	sb.append(",");
                }
                
                sb.append("\n");
            }
            
            sb.append("]");
            Path tmp = Paths.get(FILE + ".tmp");
            Files.writeString(tmp, sb.toString());
            Files.move(tmp, Paths.get(FILE), StandardCopyOption.REPLACE_EXISTING);
        
        } catch (IOException e) {
        	
            System.err.println("Save error: " + e.getMessage());
        }
    }

    private void load() {
    	
        Path p = Paths.get(FILE);
        
        if (!Files.exists(p)) {
        	
        	return;
        }
        
        try {
        	
            String json = Files.readString(p);
            Files.copy(p, Paths.get(FILE + ".bak"), StandardCopyOption.REPLACE_EXISTING);
            List<MediaItem> loaded = parseJsonArray(json);
            items.addAll(loaded);
            
        } catch (Exception e) {
        	
            System.err.println("Load error: " + e.getMessage());
        }
    }

    private String toJson(MediaItem m) {
    	
        return String.format(Locale.ROOT, """
                  {
                    "id": "%s",
                    "mediaType": "%s",
                    "title": %s,
                    "description": %s,
                    "photoPath": %s,
                    "watchStatus": "%s",
                    "genres": [%s],
                    "subGenres": [%s],
                    "vibes": [%s],
                    "rating": %.1f,
                    "review": %s,
                    "personalNote": %s,
                    "addedDate": "%s"
                  }""",
                  
                esc(m.getId()),
                m.getMediaType().name(),
                jsonStr(m.getTitle()),
                jsonStr(m.getDescription()),
                jsonStr(m.getPhotoPath()),
                m.getWatchStatus().name(),
                joinQuoted(m.getGenres().stream().map(g -> g.name()).toList()),
                joinQuoted(m.getSubGenres()),
                joinQuoted(m.getVibes()),
                m.getRating(),
                jsonStr(m.getReview()),
                jsonStr(m.getPersonalNote()),
                m.getAddedDate() != null ? m.getAddedDate().toString() : ""
        );
    }

    private String jsonStr(String s) {
    	
        if (s == null) {
        	
        	return "null";
        }
        
        return "\"" + esc(s) + "\"";
    }

    private String esc(String s) {
    	
        if (s == null) {
        	
        	return "";
        }
        
        return s.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    }

    private String joinQuoted(List<String> list) {
    	
        if (list == null || list.isEmpty()) {
        	
        	return "";
        }
        
        StringBuilder sb = new StringBuilder();
       
        for (int i = 0; i < list.size(); i++) {
        	
            sb.append("\"").append(esc(list.get(i))).append("\"");
           
            if (i < list.size() - 1) {
            	
            	sb.append(", ");
            }
        }
        return sb.toString();
    }

    //Minimal JSON parser 
    private List<MediaItem> parseJsonArray(String json) {
    	
        List<MediaItem> result = new ArrayList<>();
        json = json.trim();
        
        if (!json.startsWith("[")) {
        	
        	return result;
        }
        
        // Split by top-level objects
       
        List<String> objects = splitTopLevelObjects(json.substring(1, json.lastIndexOf(']')));
       
        for (String obj : objects) {
        	
            try {
            	
                MediaItem item = parseObject(obj.trim());
                
                if (item != null) {
                	
                	result.add(item);
                }
                
            } catch (Exception e) {
            	
                System.err.println("Parse error for object: " + e.getMessage());
            }
        }
        
        return result;
    }

    private List<String> splitTopLevelObjects(String content) {
    	
        List<String> objs = new ArrayList<>();
        int depth = 0;
        boolean inString = false, escaped = false;
        StringBuilder cur = new StringBuilder();

        for (char c : content.toCharArray()) {
        	
            if (inString) {
            	
                if (escaped) {
                	
                	escaped = false;
                
                } else if (c == '\\') {
                	
                	escaped = true;
                	
                } else if (c == '"') {
                	
                	inString = false;
                }
          
            } else if (c == '"') {
            	
            	inString = true;
          
            } else if (c == '{') {
            	
            	depth++;
            
            } else if (c == '}') {
            	
            	depth--;
            }

            cur.append(c);

            if (!inString && depth == 0 && cur.toString().trim().startsWith("{")) {
            	
                objs.add(cur.toString().trim());
                cur = new StringBuilder();
            }
        }
        return objs;
    }

    private MediaItem parseObject(String obj) {
    	
        Map<String, String> fields = new HashMap<>();
        
        // Extract all key-value pairs at top level
        
        String content = obj.trim();
        
        if (content.startsWith("{")) {
        	
        	content = content.substring(1);
        }
        
        if (content.endsWith("}")) {
        	
        	content = content.substring(0, content.length() - 1);
        }

        // Simple key extraction
        
        fields.put("id", extractStr(obj, "id"));
        fields.put("mediaType", extractStr(obj, "mediaType"));
        fields.put("title", extractStr(obj, "title"));
        fields.put("description", extractStr(obj, "description"));
        fields.put("photoPath", extractStr(obj, "photoPath"));
        fields.put("watchStatus", extractStr(obj, "watchStatus"));
        fields.put("rating", extractRaw(obj, "rating"));
        fields.put("review", extractStr(obj, "review"));
        fields.put("personalNote", extractStr(obj, "personalNote"));
        fields.put("addedDate", extractStr(obj, "addedDate"));

        List<String> genres = extractArray(obj, "genres");
        List<String> subGenres = extractArray(obj, "subGenres");
        List<String> vibes = extractArray(obj, "vibes");

        MediaItem item = new MediaItem();
        
        if (fields.get("id") != null) {
        	
        	item.idProperty().set(fields.get("id"));
        }
        
        try { 
        	
        	item.setMediaType(MediaItem.MediaType.valueOf(fields.get("mediaType"))); 
        	
        } catch (Exception ignored) {}
       
        try { 
        	
        	item.setWatchStatus(MediaItem.WatchStatus.valueOf(fields.get("watchStatus"))); 
        	
        } catch (Exception ignored) {}
        
        List<Genre> genreList = new ArrayList<>();
       
        for (String g : genres) {
        	
            try { 
            	genreList.add(Genre.valueOf(g)); 
            	
            } catch (Exception ignored) {}
        }
        
        item.setGenres(genreList);
        item.setSubGenres(subGenres);
        item.setVibes(vibes);
        
        if (fields.get("rating") != null) {
        	
            try { 
            	
            	item.setRating(Double.parseDouble(fields.get("rating")));
            	
            } catch (Exception ignored) {}
        }
        
        item.setReview(fields.get("review"));
        item.setPersonalNote(fields.get("personalNote"));
        
        if (fields.get("addedDate") != null && !fields.get("addedDate").isBlank()) {
        	
            try { 
            	
            	item.addedDateProperty().set(LocalDate.parse(fields.get("addedDate")));
            	
            } catch (Exception ignored) {}
        }
        return item;
    }

    private String extractStr(String json, String key) {
    	
        String pattern = "\"" + key + "\"";
        int idx = json.indexOf(pattern);
        
        if (idx < 0) {
        	
        	return null;
        }
        
        int colon = json.indexOf(':', idx + pattern.length());
        
        if (colon < 0) {
        	
        	return null;
        }
        int start = colon + 1;
        
        while (start < json.length() && json.charAt(start) == ' ') {
        	
        	start++;
        }
        
        if (start >= json.length()) {
        	
        	return null;
        }
        
        if (json.charAt(start) == '"') {
        	
        	int end = start + 1;
        	StringBuilder sb = new StringBuilder();
        	
        	while (end < json.length()) {
        		
        	    char ch = json.charAt(end);
        	    
        	    if (ch == '\\' && end + 1 < json.length()) {
        	    	
        	        char n = json.charAt(end + 1);
        	       
        	        switch (n) {
        	        
        	            case 'n' -> sb.append('\n');
        	            case 't' -> sb.append('\t');
        	            case 'r' -> sb.append('\r');
        	            default -> sb.append(n);
        	        }
        	        
        	        end += 2;
        	        
        	    } else if (ch == '"') {
        	    	
        	        break;
        	        
        	    } else {
        	    	
        	        sb.append(ch);
        	        end++;
        	    }
        	}
        	
        	return sb.toString();
       
        } else if (json.startsWith("null", start)) {
        	
            return null;
        }
        
        return null;
    }

    private String extractRaw(String json, String key) {
    	
        String pattern = "\"" + key + "\"";
        int idx = json.indexOf(pattern);
        
        if (idx < 0) {
        	
        	return null;
        }
        
        int colon = json.indexOf(':', idx + pattern.length());
       
        if (colon < 0) {
        	
        	return null;
        }
        
        int start = colon + 1;
       
        while (start < json.length() && json.charAt(start) == ' ') {
        	
        	start++;
        }
        
        int end = start;
        
        while (end < json.length() && json.charAt(end) != ',' && json.charAt(end) != '\n' && json.charAt(end) != '}') {
        	
        	end++;
        }
        return json.substring(start, end).trim();
    }

    private List<String> extractArray(String json, String key) {
    	
        List<String> result = new ArrayList<>();
        String pattern = "\"" + key + "\"";
        int idx = json.indexOf(pattern);
        
        if (idx < 0) {
        	
        	return result;
        }
        
        int bracket = json.indexOf('[', idx);
        if (bracket < 0) {
        	
        	return result;
        }
        
        int end = json.indexOf(']', bracket);
        
        if (end < 0) {
        	
        	return result;
        }
        
        String content = json.substring(bracket + 1, end).trim();
        
        if (content.isBlank()) {
        	
        	return result;
        }
        
        for (String part : content.split(",")) {
        	
            String s = part.trim().replaceAll("^\"|\"$", "");
           
            if (!s.isBlank()) {
            	
            	result.add(s);
            }
        }
        return result;
    }
}
