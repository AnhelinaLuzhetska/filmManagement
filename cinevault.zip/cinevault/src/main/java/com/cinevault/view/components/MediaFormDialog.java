package com.cinevault.view.components;

import com.cinevault.controller.MainController;
import com.cinevault.model.Genre;
import com.cinevault.model.MediaItem;
import com.cinevault.model.Vibe;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.*;

import java.io.File;
import java.util.*;

import java.nio.file.*;


public class MediaFormDialog extends Stage {

    private final MainController controller;
    private final MediaItem editingItem;
    private final boolean isEdit;

    // Form fields
    
    private TextField titleField;
    private TextArea descriptionArea;
    private ToggleGroup typeGroup;
    private ToggleGroup statusGroup;
    private Slider ratingSlider;
    private Label ratingLabel;
    private TextArea reviewArea;
    private TextArea noteArea;
    private String selectedPhotoPath;
    private ImageView photoPreview;
    private final List<CheckBox> genreCheckBoxes = new ArrayList<>();
    private final Map<Genre, List<CheckBox>> subGenreCheckBoxes = new HashMap<>();
    private VBox subgenreContainer;
    private final List<CheckBox> vibeCheckBoxes = new ArrayList<>();

    public MediaFormDialog(MediaItem existingItem, MainController controller) {
       
    	this.controller = controller;
        this.isEdit = existingItem != null;
        this.editingItem = isEdit ? existingItem : new MediaItem();

        setTitle(isEdit ? "✏  Modify Media" : "＋  Add Media");
        initModality(Modality.APPLICATION_MODAL);
        initStyle(StageStyle.DECORATED);

        ScrollPane scroll = new ScrollPane();
        scroll.setFitToWidth(true);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        VBox form = buildForm();
        form.setPadding(new Insets(24));
        scroll.setContent(form);

        Scene scene = new Scene(scroll, 660, 780);
        scene.getStylesheets().add(getClass().getResource("/css/" + controller.getCurrentTheme() + ".css").toExternalForm());
        setScene(scene);

        if (isEdit) {
        	
        	populateFields();
        }
    }
    
    private String copyToLibrary(File src) {
        try {
            Path dir = Paths.get(System.getProperty("user.home"), ".cinevault", "posters");
            Files.createDirectories(dir);
            String name = UUID.randomUUID() + src.getName().substring(src.getName().lastIndexOf('.'));
            Path dest = dir.resolve(name);
            Files.copy(src.toPath(), dest);
            return dest.toString();
        } catch (Exception e) {
            return src.getAbsolutePath();
        }
    }

    private VBox buildForm() {
    	
        VBox form = new VBox(16);
        form.getStyleClass().add("form-container");

        Label heading = new Label(isEdit ? "MODIFY MEDIA" : "ADD MEDIA");
        heading.getStyleClass().add("form-heading");

        // Media Type
        
        Label typeLabel = formLabel("TYPE");
        typeGroup = new ToggleGroup();
        HBox typeRow = new HBox(12);
        RadioButton filmRb = styledRadio("🎬 Film", MediaItem.MediaType.FILM, typeGroup);
        RadioButton serieRb = styledRadio("📺 TV Series", MediaItem.MediaType.TV_SERIES, typeGroup);
        filmRb.setSelected(true);
        typeRow.getChildren().addAll(filmRb, serieRb);

        //Title
        
        Label titleLabel = formLabel("TITLE *");
        titleField = new TextField();
        titleField.getStyleClass().add("neon-text-field");
        titleField.setPromptText("Enter the title");

        // Description
        
        Label descLabel = formLabel("DESCRIPTION");
        descriptionArea = new TextArea();
        descriptionArea.getStyleClass().add("neon-text-area");
        descriptionArea.setPromptText("Enter the description");
        descriptionArea.setPrefRowCount(3);
        descriptionArea.setWrapText(true);

        // Photo
        
        Label photoLabel = formLabel("PHOTO / POSTER");
        photoPreview = new ImageView();
        photoPreview.setFitWidth(120); photoPreview.setFitHeight(80);
        photoPreview.setPreserveRatio(true);
        photoPreview.setStyle("-fx-background-color: #1a1a2e;");
        Rectangle clip = new Rectangle(120, 80);
        clip.setArcWidth(8); clip.setArcHeight(8);
        photoPreview.setClip(clip);
        Button photoBtn = new Button("📁  Choose the image");
        photoBtn.getStyleClass().add("secondary-btn");
        photoBtn.setOnAction(e -> choosePhoto());
        HBox photoRow = new HBox(12, photoPreview, photoBtn);
        photoRow.setAlignment(Pos.CENTER_LEFT);

        //Status 
        
        Label statusLabel = formLabel("STATE");
        statusGroup = new ToggleGroup();
        HBox statusRow = new HBox(12);
        RadioButton seenRb = styledRadio("Seen", MediaItem.WatchStatus.SEEN, statusGroup);
        RadioButton must_SeeRb = styledRadio("Must-See", MediaItem.WatchStatus.MUST_SEE, statusGroup);
        must_SeeRb.setSelected(true);
        statusRow.getChildren().addAll(seenRb, must_SeeRb);

        // Watched section (rating + review)
        
        VBox watchedSection = new VBox(10);
        watchedSection.getStyleClass().add("form-section-box");
        Label ratLabel = formLabel("RATING (1–10)");
        ratingSlider = new Slider(1, 10, 5);
        ratingSlider.setShowTickLabels(true);
        ratingSlider.setMajorTickUnit(1);
        ratingSlider.setSnapToTicks(true);
        ratingSlider.setMinorTickCount(0);
        ratingSlider.getStyleClass().add("rating-slider");
        ratingLabel = new Label("5.0 ★★★");
        ratingLabel.getStyleClass().add("form-rating-label");
        ratingSlider.valueProperty().addListener((obs, old, nv) -> updateRatingLabel(nv.doubleValue()));
        Label revLabel = formLabel("REVIEW");
        reviewArea = new TextArea();
        reviewArea.getStyleClass().add("neon-text-area");
        reviewArea.setPromptText("Your thoughts/comments");
        reviewArea.setPrefRowCount(3);
        reviewArea.setWrapText(true);
        watchedSection.getChildren().addAll(ratLabel, ratingSlider, ratingLabel, revLabel, reviewArea);

        // Unwatched note
        
        VBox unwatchedSection = new VBox(8);
        unwatchedSection.getStyleClass().add("form-section-box");
        Label noteLabel = formLabel("WHY DO YOU WANT TO WATCH IT?");
        noteArea = new TextArea();
        noteArea.getStyleClass().add("neon-text-area");
        noteArea.setPromptText("Personal notes");
        noteArea.setPrefRowCount(2);
        noteArea.setWrapText(true);
        unwatchedSection.getChildren().addAll(noteLabel, noteArea);

        // Show/hide based on status
        
        watchedSection.setVisible(false); watchedSection.setManaged(false);
        statusGroup.selectedToggleProperty().addListener((obs, old, nw) -> {
            boolean watched = nw.getUserData() == MediaItem.WatchStatus.SEEN;
            watchedSection.setVisible(watched); watchedSection.setManaged(watched);
            unwatchedSection.setVisible(!watched); unwatchedSection.setManaged(!watched);
        });

        // Genres
       
        Label genreLabel = formLabel("GENRE * (at least one)");
        FlowPane genreFlow = new FlowPane(8, 6);
        
        for (Genre g : Genre.values()) {
        	
            CheckBox cb = new CheckBox(g.getDisplayName());
            cb.getStyleClass().add("genre-checkbox");
            Rectangle dot = new Rectangle(10, 10, Color.web(g.getColor()));
            dot.setArcWidth(4); dot.setArcHeight(4);
            cb.setGraphic(dot);
            cb.setUserData(g);
            genreCheckBoxes.add(cb);
            cb.selectedProperty().addListener((obs, old, nv) -> updateSubgenres());
            genreFlow.getChildren().add(cb);
        }

        // Subgenres
        
        Label subLabel = formLabel("SUBGENRE (optional)");
        subgenreContainer = new VBox(4);
        subgenreContainer.getStyleClass().add("subgenre-container");

        // Vibes
        
        Label vibeLabel = formLabel("VIBE");
        FlowPane vibeFlow = new FlowPane(6, 6);
        
        for (String vibe : Vibe.ALL_VIBES) {
        	
            CheckBox cb = new CheckBox(vibe);
            cb.getStyleClass().add("vibe-checkbox-form");
            vibeCheckBoxes.add(cb);
            vibeFlow.getChildren().add(cb);
        }

        // Buttons
        
        HBox btnRow = new HBox(12);
        btnRow.setAlignment(Pos.CENTER_RIGHT);
        Button cancelBtn = new Button("Cancel");
        cancelBtn.getStyleClass().add("secondary-btn");
        cancelBtn.setOnAction(e -> close());
        Button saveBtn = new Button(isEdit ? "💾  Save Changes" : "＋  Add");
        saveBtn.getStyleClass().add("add-btn");
        saveBtn.setOnAction(e -> saveItem());
        btnRow.getChildren().addAll(cancelBtn, saveBtn);

        form.getChildren().addAll(
            heading,
            new Separator(),
            typeLabel, typeRow,
            titleLabel, titleField,
            descLabel, descriptionArea,
            photoLabel, photoRow,
            statusLabel, statusRow,
            watchedSection,
            unwatchedSection,
            genreLabel, genreFlow,
            subLabel, subgenreContainer,
            vibeLabel, vibeFlow,
            new Separator(),
            btnRow
        );

        return form;
    }

    private void updateSubgenres() {
    	
    	Set<String> previous = new HashSet<>();
    	subGenreCheckBoxes.values().forEach(l -> l.stream().filter(CheckBox::isSelected).forEach(c -> previous.add(c.getText())));
        subgenreContainer.getChildren().clear();
        subGenreCheckBoxes.clear();
       
        for (CheckBox gcb : genreCheckBoxes) {
        	
            if (gcb.isSelected()) {
            	
                Genre genre = (Genre) gcb.getUserData();
                Label sectionLbl = new Label("  ↳ " + genre.getDisplayName());
                sectionLbl.getStyleClass().add("subgenre-section-label");
                sectionLbl.setStyle("-fx-text-fill: " + genre.getColor() + ";");
                subgenreContainer.getChildren().add(sectionLbl);
                FlowPane subFlow = new FlowPane(6, 4);
                List<CheckBox> list = new ArrayList<>();
               
                for (String sub : genre.getSubGenres()) {
                	
                    CheckBox scb = new CheckBox(sub);
                    scb.setSelected(previous.contains(sub));
                    scb.getStyleClass().add("subgenre-checkbox");
                    list.add(scb);
                    subFlow.getChildren().add(scb);
                }
                subGenreCheckBoxes.put(genre, list);
                subgenreContainer.getChildren().add(subFlow);
            }
        }
    }

    private void choosePhoto() {
    	
        FileChooser fc = new FileChooser();
        fc.setTitle("Choose poster image");
        fc.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Images", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.webp")
        );
        
        File file = fc.showOpenDialog(this);
        
        if (file != null) {
        	
            selectedPhotoPath = file.getAbsolutePath();
          
            try {
            	
                photoPreview.setImage(new Image(file.toURI().toString(), 120, 80, true, true));
           
            } catch (Exception ignored) {}
        }
    }

    private void saveItem() {
    	
        if (titleField.getText() == null || titleField.getText().isBlank()) {
        	
            showError("The title is mandatory");
            return;
        }
        
        List<Genre> selectedGenres = new ArrayList<>();
        
        for (CheckBox cb : genreCheckBoxes) {
        	
            if (cb.isSelected()) {
            	
            	selectedGenres.add((Genre) cb.getUserData());
            }
        }
        
        if (selectedGenres.isEmpty()) {
        	
            showError("Choose atleast one genre");
            return;
        }

        editingItem.setTitle(titleField.getText().trim());
        editingItem.setDescription(descriptionArea.getText());
        
        if (selectedPhotoPath != null && !selectedPhotoPath.equals(editingItem.getPhotoPath())) {
        	
            editingItem.setPhotoPath(copyToLibrary(new File(selectedPhotoPath)));
        }
        
        editingItem.setGenres(selectedGenres);
        editingItem.setMediaType((MediaItem.MediaType) typeGroup.getSelectedToggle().getUserData());

        // Subgenres
        
        List<String> subs = new ArrayList<>();
        
        for (Map.Entry<Genre, List<CheckBox>> entry : subGenreCheckBoxes.entrySet()) {
        	
            for (CheckBox scb : entry.getValue()) {
            	
                if (scb.isSelected()) {
                	
                	subs.add(scb.getText());
                }
            }
        }
        editingItem.setSubGenres(subs);

        // Vibes
        
        List<String> vibes = new ArrayList<>();
        
        for (CheckBox vcb : vibeCheckBoxes) {
        	
            if (vcb.isSelected()) {
            	
            	vibes.add(vcb.getText());
            }
        }
        editingItem.setVibes(vibes);

        // Status
        
        MediaItem.WatchStatus status = (MediaItem.WatchStatus) statusGroup.getSelectedToggle().getUserData();
        editingItem.setWatchStatus(status);
        
        if (status == MediaItem.WatchStatus.SEEN) {
        	
            editingItem.setRating(ratingSlider.getValue());
            editingItem.setReview(reviewArea.getText());
            
        } else {
        	
            editingItem.setPersonalNote(noteArea.getText());
        }

        if (isEdit) {
        	
            controller.updateItem(editingItem);
      
        } else {
        	
            controller.addItem(editingItem);
        }
        close();
    }

    private void populateFields() {
    	
        titleField.setText(editingItem.getTitle());
        descriptionArea.setText(editingItem.getDescription());
        selectedPhotoPath = editingItem.getPhotoPath();
       
        if (selectedPhotoPath != null && !selectedPhotoPath.isBlank()) {
        	
            try {
            	
                photoPreview.setImage(new Image(new File(selectedPhotoPath).toURI().toString(), 120, 80, true, true));
           
            } catch (Exception ignored) {}
        }
        
        // Status
        
        statusGroup.getToggles().forEach(t -> {
        	
            if (t.getUserData() == editingItem.getWatchStatus()) {
            	
            	t.setSelected(true);
            }
            
        });
        
        // Type
        
        typeGroup.getToggles().forEach(t -> {
        	
            if (t.getUserData() == editingItem.getMediaType()) {
            	
            	t.setSelected(true);
            }
        });
        
        // Rating
        
        if (editingItem.getRating() > 0) {
        	
        	ratingSlider.setValue(editingItem.getRating());
        }
        
        if (editingItem.getReview() != null) {
        	
        	reviewArea.setText(editingItem.getReview());
        }
        
        if (editingItem.getPersonalNote() != null) {
        	
        	noteArea.setText(editingItem.getPersonalNote());
        }
        
        // Genres
        
        for (CheckBox cb : genreCheckBoxes) {
        	
            Genre g = (Genre) cb.getUserData();
            
            if (editingItem.getGenres().contains(g)) {
            	
            	cb.setSelected(true);
            }
        }
        
        updateSubgenres();
        
        // Subgenres
        
        for (Map.Entry<Genre, List<CheckBox>> entry : subGenreCheckBoxes.entrySet()) {
           
        	for (CheckBox scb : entry.getValue()) {
        		
                if (editingItem.getSubGenres().contains(scb.getText())) {
                	
                	scb.setSelected(true);
                }
            }
        }
        
        // Vibes
        
        for (CheckBox vcb : vibeCheckBoxes) {
        	
            if (editingItem.getVibes().contains(vcb.getText())) {
            	
            	vcb.setSelected(true);
            }
        }
    }

    private void updateRatingLabel(double val) {
    	
        int stars = (int) Math.round(val / 2);
        StringBuilder sb = new StringBuilder();
        
        for (int i = 0; i < 5; i++) {
        	
        	sb.append(i < stars ? "★" : "☆");
        }
        
        ratingLabel.setText(String.format("%.1f  %s", val, sb));
    }

    private void showError(String msg) {
    	
        Alert a = new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK);
        a.setHeaderText(null);
        a.showAndWait();
    }

    private Label formLabel(String text) {
    	
        Label l = new Label(text);
        l.getStyleClass().add("form-label");
        return l;
    }

    private RadioButton styledRadio(String text, Object userData, ToggleGroup group) {
    	
        RadioButton rb = new RadioButton(text);
        rb.setToggleGroup(group);
        rb.setUserData(userData);
        rb.getStyleClass().add("neon-radio");
        return rb;
    }
}
