package com.cinevault.view;

import com.cinevault.controller.MainController;
import com.cinevault.model.MediaItem;
import com.cinevault.view.components.FilterSidebar;
import com.cinevault.view.components.GalleryView;
import com.cinevault.view.components.MediaFormDialog;
import com.cinevault.view.components.TopBar;
import javafx.geometry.Insets;
import javafx.scene.layout.*;

public class MainView {

    private final BorderPane root;
    private final MainController controller;
    private final GalleryView galleryView;
    private final FilterSidebar filterSidebar;
    private final TopBar topBar;

    public MainView(MainController controller) {
    	
        this.controller = controller;
        this.root = new BorderPane();
        this.root.getStyleClass().add("main-root");

        topBar = new TopBar(controller);
        filterSidebar = new FilterSidebar(controller);
        galleryView = new GalleryView(controller);

        root.setTop(topBar.getNode());
        root.setLeft(filterSidebar.getNode());
        root.setCenter(galleryView.getNode());

        BorderPane.setMargin(galleryView.getNode(), new Insets(0, 10, 10, 10));

        // Wire controller callbacks
        
        controller.setOnEditRequest(item -> openEditDialog(item));
        controller.setOnDetailRequest(item -> openDetailView(item));

        // Wire topbar add button
        
        topBar.setOnAddClicked(() -> openAddDialog());
        topBar.setOnThemeToggle(() -> {
            controller.toggleTheme(root.getScene());
        });
    }

    private void openAddDialog() {
    	
        MediaFormDialog dialog = new MediaFormDialog(null, controller);
        dialog.showAndWait();
    }

    private void openEditDialog(MediaItem item) {
    	
        MediaFormDialog dialog = new MediaFormDialog(item, controller);
        dialog.showAndWait();
    }

    private void openDetailView(MediaItem item) {
    	
        MediaDetailModal detail = new MediaDetailModal(item, controller);
        detail.show();
    }

    public BorderPane getRoot() { 
    	
    	return root; 
    }
}
