package com.cinevault.view.components;

import com.cinevault.controller.MainController;

import com.cinevault.model.Genre;
import com.cinevault.model.MediaItem;
import javafx.animation.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.util.Duration;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class MediaCard {

    private final VBox node;
    private final MediaItem item;
    private final MainController controller;

    public MediaCard(MediaItem item, MainController controller) {
     
    	this.item = item;
        this.controller = controller;

        node = new VBox(0);
        node.getStyleClass().add("media-card");
        node.setPrefSize(200, 300);
        node.setMaxSize(200, 300);
        node.setCursor(javafx.scene.Cursor.HAND);

        // Apply genre gradient background
        
        applyGenreStyle();

        // Poster Image
        
        StackPane imagePane = buildImagePane();

        // Info Section
        
        VBox infoBox = new VBox(4);
        infoBox.getStyleClass().add("card-info-box");
        infoBox.setPadding(new Insets(8, 8, 8, 8));
        VBox.setVgrow(infoBox, Priority.ALWAYS);

        // Title
        
        Label titleLabel = new Label(item.getTitle() != null ? item.getTitle() : "Without a title");
        titleLabel.getStyleClass().add("card-title");
        titleLabel.setWrapText(true);
        titleLabel.setMaxWidth(184);

        // Type badge
        
        Label typeBadge = new Label(item.getMediaType() == MediaItem.MediaType.FILM ? "🎬 Film" : "📺 TV Series");
        typeBadge.getStyleClass().add("type-badge");

        // Genre tags
        
        FlowPane genreTags = buildGenreTags();

        // Vibe tags
        
        FlowPane vibeTags = buildVibeTags();

        // Rating / Status
        
        HBox bottomRow = buildBottomRow();

        infoBox.getChildren().addAll(typeBadge, titleLabel, genreTags, vibeTags);

        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);
        infoBox.getChildren().addAll(spacer, bottomRow);

        node.getChildren().addAll(imagePane, infoBox);

        // Hover Animations
        
        setupHoverAnimations();

        // Context Menu
        
        ContextMenu ctx = buildContextMenu();
        node.setOnContextMenuRequested(e -> ctx.show(node, e.getScreenX(), e.getScreenY()));

        // Click to detail 
        
        node.setOnMouseClicked(e -> {
          
        	if (e.getButton() == javafx.scene.input.MouseButton.PRIMARY) {
                
        		controller.requestDetail(item);
            }
        });
    }

    
    private static final Map<String, Image> IMAGE_CACHE = new HashMap<>();
    
    private void applyGenreStyle() {
    	
        if (item.getGenres().isEmpty()) {
        	
            node.setStyle("-fx-background-color: #1a1a2e; -fx-border-color: #333; -fx-border-width: 1; -fx-border-radius: 10; -fx-background-radius: 10;");
    
        } else {
        	
            String g1 = item.getGenres().get(0).getColor();
            String borderColor = g1;
            String bg;
           
            if (item.getGenres().size() >= 2) {
            	
                String g2 = item.getGenres().get(1).getColor();
                bg = String.format("linear-gradient(to bottom, %s44, %s22, #0d0d14)", g1, g2);
         
            } else {
            	
                bg = String.format("linear-gradient(to bottom, %s44, #0d0d14)", g1);
            }
            
            node.setStyle(String.format(
                "-fx-background-color: %s; " +
                "-fx-border-color: %s; " +
                "-fx-border-width: 1.5; " +
                "-fx-border-radius: 10; " +
                "-fx-background-radius: 10; " +
                "-fx-effect: dropshadow(gaussian, %s, 8, 0.3, 0, 0);",
                bg, borderColor, borderColor
            ));
        }
    }

    private StackPane buildImagePane() {
    	
        StackPane imagePane = new StackPane();
        imagePane.setPrefHeight(160);
        imagePane.setMaxHeight(160);
        imagePane.getStyleClass().add("card-image-pane");

        // Clip to rounded top
        
        Rectangle clip = new Rectangle(200, 160);
        clip.setArcWidth(20); clip.setArcHeight(20);
        imagePane.setClip(clip);

        if (item.getPhotoPath() != null && !item.getPhotoPath().isBlank()) {
          
        	try {
        		
                File f = new File(item.getPhotoPath());
              
                if (f.exists()) {
                	
                	Image img = IMAGE_CACHE.computeIfAbsent(f.getAbsolutePath(),
                	        p -> new Image(f.toURI().toString(), 200, 160, false, true, true));
                	
                	ImageView iv = new ImageView(img);
                    iv.setFitWidth(200); iv.setFitHeight(160);
                    iv.setPreserveRatio(false);
                    imagePane.getChildren().add(iv);
              
                } else {
                	
                    imagePane.getChildren().add(buildPlaceholder());
                }
                
            } catch (Exception e) {
            	
                imagePane.getChildren().add(buildPlaceholder());
            }
        	
        } else {
        	
            imagePane.getChildren().add(buildPlaceholder());
        }

        // Status badge overlay
        
        Label statusBadge = new Label(item.getWatchStatus() == MediaItem.WatchStatus.SEEN ? "SEEN" : "MUST-SEE");
        statusBadge.getStyleClass().add(item.getWatchStatus() == MediaItem.WatchStatus.SEEN ? "badge-watched" : "badge-unwatched");
        StackPane.setAlignment(statusBadge, Pos.TOP_RIGHT);
        StackPane.setMargin(statusBadge, new Insets(6, 6, 0, 0));
        imagePane.getChildren().add(statusBadge);

        return imagePane;
    }

    private VBox buildPlaceholder() {
    	
        VBox ph = new VBox();
        ph.setAlignment(Pos.CENTER);
        ph.setPrefSize(200, 160);
        String color = item.getGenres().isEmpty() ? "#1a1a2e" : item.getGenres().get(0).getColor() + "44";
        ph.setStyle("-fx-background-color: " + color + ";");
        Label icon = new Label(item.getMediaType() == MediaItem.MediaType.FILM ? "🎬" : "📺");
        icon.setStyle("-fx-font-size: 40;");
        ph.getChildren().add(icon);
        return ph;
    }

    private FlowPane buildGenreTags() {
    	
        FlowPane flow = new FlowPane(4, 2);
        flow.setPadding(new Insets(2, 0, 0, 0));
        
        for (Genre g : item.getGenres()) {
        	
            Label tag = new Label(g.getDisplayName());
            tag.getStyleClass().add("genre-tag");
            tag.setStyle(String.format(
                "-fx-background-color: %s33; -fx-border-color: %s88; -fx-text-fill: %s;",
                g.getColor(), g.getColor(), g.getColor()
            ));
            flow.getChildren().add(tag);
        }
        
        return flow;
    }

    private FlowPane buildVibeTags() {
    	
        FlowPane flow = new FlowPane(3, 2);
        int count = 0;
        
        for (String vibe : item.getVibes()) {
        	
            if (count >= 3) {
            	
            	break; // max 3 vibes shown on card
            }
            
            Label tag = new Label(vibe);
            tag.getStyleClass().add("vibe-tag");
            flow.getChildren().add(tag);
            count++;
        }
        
        return flow;
    }

    private HBox buildBottomRow() {
    	
        HBox row = new HBox(4);
        row.setAlignment(Pos.CENTER_LEFT);

        if (item.getWatchStatus() == MediaItem.WatchStatus.SEEN && item.getRating() > 0) {
        	
            Label stars = new Label(buildStars(item.getRating()));
            stars.getStyleClass().add("card-rating");
            Label ratingNum = new Label(String.format("%.1f", item.getRating()));
            ratingNum.getStyleClass().add("card-rating-num");
            row.getChildren().addAll(stars, ratingNum);
      
        } else {
        	
            Label noRating = new Label("must-see");
            noRating.getStyleClass().add("card-no-rating");
            row.getChildren().add(noRating);
        }

        return row;
    }

    private String buildStars(double rating) {
    	
        int full = (int) Math.round(rating / 2);
        StringBuilder sb = new StringBuilder();
        
        for (int i = 0; i < 5; i++) {
        	
            sb.append(i < full ? "★" : "☆");
        }
        
        return sb.toString();
    }

    private void setupHoverAnimations() {
    	
        ScaleTransition scaleUp = new ScaleTransition(Duration.millis(180), node);
        scaleUp.setToX(1.04);
        scaleUp.setToY(1.04);

        ScaleTransition scaleDown = new ScaleTransition(Duration.millis(180), node);
        scaleDown.setToX(1.0);
        scaleDown.setToY(1.0);

        String baseStyle = node.getStyle();
        String glowColor = item.getGenres().isEmpty() ? "#FF007F" : item.getGenres().get(0).getColor();

        node.setOnMouseEntered(e -> {
        	
            scaleUp.play();
            node.setStyle(baseStyle + String.format(
                " -fx-effect: dropshadow(gaussian, %s, 20, 0.6, 0, 0);", glowColor
            ));
        });

        node.setOnMouseExited(e -> {
        	
            scaleDown.play();
            node.setStyle(baseStyle);
        });
    }

    private ContextMenu buildContextMenu() {
    	
        ContextMenu ctx = new ContextMenu();
        ctx.getStyleClass().add("neon-context-menu");

        MenuItem editItem = new MenuItem("✏  Modify");
        editItem.setOnAction(e -> controller.requestEdit(item));

        MenuItem toggleWatch = new MenuItem(
            item.getWatchStatus() == MediaItem.WatchStatus.SEEN ? "Mark as Must-See" : "Mark as Seen"
        );
        
        toggleWatch.setOnAction(e -> {
        	
            if (item.getWatchStatus() == MediaItem.WatchStatus.SEEN) {
            	
                item.setWatchStatus(MediaItem.WatchStatus.MUST_SEE);
          
            } else {
            	
                item.setWatchStatus(MediaItem.WatchStatus.SEEN);
            }
            controller.updateItem(item);
        });

        MenuItem deleteItem = new MenuItem("🗑  Delete");
       
        deleteItem.setOnAction(e -> {
        	
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Eliminare \"" + item.getTitle() + "\"?",
                ButtonType.YES, ButtonType.NO);
            confirm.setHeaderText(null);
            confirm.showAndWait().ifPresent(bt -> {
                
            	if (bt == ButtonType.YES) {
            		
            		controller.removeItem(item);
            	}
            });
        });

        ctx.getItems().addAll(editItem, toggleWatch, new SeparatorMenuItem(), deleteItem);
        return ctx;
    }

    public VBox getNode() { 
    	
    	return node; 
    }
}
