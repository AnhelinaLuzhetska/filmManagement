package com.cinevault.view;

import com.cinevault.controller.MainController;
import com.cinevault.model.Genre;
import com.cinevault.model.MediaItem;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.*;

import java.io.File;

public class MediaDetailModal extends Stage {

    public MediaDetailModal(MediaItem item, MainController controller) {
      
    	setTitle(item.getTitle());
        initModality(Modality.APPLICATION_MODAL);
        initStyle(StageStyle.DECORATED);

        String g1 = item.getGenres().isEmpty() ? "#0B0B0E" : item.getGenres().get(0).getColor();

        BorderPane root = new BorderPane();
        root.getStyleClass().add("detail-root");
        root.setStyle(String.format("-fx-background-color: linear-gradient(to bottom right, %s22, #0B0B0E 60%%);", g1));

        //LEFT: poster 
        
        VBox leftPane = new VBox(12);
        leftPane.setPrefWidth(240);
        leftPane.setPadding(new Insets(24));
        leftPane.setAlignment(Pos.TOP_CENTER);

        StackPane posterPane = new StackPane();
        posterPane.setPrefSize(200, 280);
        Rectangle clip = new Rectangle(200, 280);
        clip.setArcWidth(14); clip.setArcHeight(14);
        posterPane.setClip(clip);

        if (item.getPhotoPath() != null && !item.getPhotoPath().isBlank()) {
         
        	try {
        		
                File f = new File(item.getPhotoPath());
               
                if (f.exists()) {
                	
                    ImageView iv = new ImageView(new Image(f.toURI().toString(), 200, 280, false, true));
                    iv.setFitWidth(200); iv.setFitHeight(280);
                    posterPane.getChildren().add(iv);
               
                } else {
                	
                    posterPane.getChildren().add(placeholderPoster(item));
                }
                
            } catch (Exception e) {
            	
                posterPane.getChildren().add(placeholderPoster(item));
            }
        	
        } else {
        	
            posterPane.getChildren().add(placeholderPoster(item));
        }

        // Type & status badges
        
        Label typeBadge = new Label(item.getMediaType() == MediaItem.MediaType.FILM ? "🎬 Film" : "📺 TV Series");
        typeBadge.getStyleClass().add("detail-type-badge");
        Label statusBadge = new Label(item.getWatchStatus() == MediaItem.WatchStatus.SEEN ? "SEEN" : "MUST-SEE");
        statusBadge.getStyleClass().add(item.getWatchStatus() == MediaItem.WatchStatus.SEEN ? "badge-watched" : "badge-unwatched");

        // Actions
        
        Button editBtn = new Button("✏  Modify");
        editBtn.getStyleClass().add("secondary-btn");
        editBtn.setMaxWidth(Double.MAX_VALUE);
        editBtn.setOnAction(e -> { close(); controller.requestEdit(item); });

        Button deleteBtn = new Button("🗑  Delete");
        deleteBtn.getStyleClass().add("danger-btn");
        deleteBtn.setMaxWidth(Double.MAX_VALUE);
        deleteBtn.setOnAction(e -> {
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Eliminare \"" + item.getTitle() + "\"?", ButtonType.YES, ButtonType.NO);
            confirm.setHeaderText(null);
            confirm.showAndWait().ifPresent(bt -> {
                if (bt == ButtonType.YES) { controller.removeItem(item); close(); }
            });
        });

        leftPane.getChildren().addAll(posterPane, typeBadge, statusBadge, new Separator(), editBtn, deleteBtn);

        //  RIGHT: details 
        
        ScrollPane scroll = new ScrollPane();
        scroll.setFitToWidth(true);
        scroll.getStyleClass().add("detail-scroll");

        VBox rightPane = new VBox(16);
        rightPane.setPadding(new Insets(28, 28, 28, 16));

        // Title
        
        Label titleLbl = new Label(item.getTitle() != null ? item.getTitle() : "No title");
        titleLbl.getStyleClass().add("detail-title");
        titleLbl.setWrapText(true);
        titleLbl.setStyle(String.format("-fx-text-fill: white; -fx-effect: dropshadow(gaussian, %s, 12, 0.5, 0, 0);", g1));

        // Genre tags
        
        FlowPane genreFlow = new FlowPane(8, 6);
        
        for (Genre g : item.getGenres()) {
        	
            Label tag = new Label(g.getDisplayName());
            tag.getStyleClass().add("genre-tag");
            tag.setStyle(String.format(
                "-fx-background-color: %s33; -fx-border-color: %s88; -fx-text-fill: %s; -fx-font-size: 12px;",
                g.getColor(), g.getColor(), g.getColor()
            ));
            genreFlow.getChildren().add(tag);
        }

        // Subgenre tags
        
        FlowPane subFlow = new FlowPane(6, 4);
        
        for (String sub : item.getSubGenres()) {
        	
            Label tag = new Label("▸ " + sub);
            tag.getStyleClass().add("subgenre-tag");
            subFlow.getChildren().add(tag);
        }

        // Vibe tags
        
        FlowPane vibeFlow = new FlowPane(6, 4);
        
        for (String vibe : item.getVibes()) {
        	
            Label tag = new Label(vibe);
            tag.getStyleClass().add("vibe-tag");
            vibeFlow.getChildren().add(tag);
        }

        // Description
        
        VBox descSection = new VBox(6);
        
        if (item.getDescription() != null && !item.getDescription().isBlank()) {
            
        	Label descHead = sectionHead("PLOT");
            Label descText = new Label(item.getDescription());
            descText.getStyleClass().add("detail-description");
            descText.setWrapText(true);
            descSection.getChildren().addAll(descHead, descText);
        }

        // Rating / Note
        
        VBox extraSection = new VBox(8);
        
        if (item.getWatchStatus() == MediaItem.WatchStatus.SEEN) {
            
        	Label ratingHead = sectionHead("RATING");
            double r = item.getRating();
            int stars = (int) Math.round(r / 2);
            StringBuilder sb = new StringBuilder();
           
            for (int i = 0; i < 5; i++) sb.append(i < stars ? "★" : "☆");
           
            Label ratingLbl = new Label(String.format("%.1f / 10   %s", r, sb));
            ratingLbl.getStyleClass().add("detail-rating");
            ratingLbl.setStyle(String.format("-fx-text-fill: %s;", g1));
            extraSection.getChildren().addAll(ratingHead, ratingLbl);

            if (item.getReview() != null && !item.getReview().isBlank()) {
              
            	Label revHead = sectionHead("REVIEW");
                Label revLbl = new Label("❝  " + item.getReview() + "  ❞");
                revLbl.getStyleClass().add("detail-review");
                revLbl.setWrapText(true);
                extraSection.getChildren().addAll(revHead, revLbl);
            }
            
        } else {
        	
            if (item.getPersonalNote() != null && !item.getPersonalNote().isBlank()) {
               
            	Label noteHead = sectionHead("PERSONAL COMMENT");
                Label noteLbl = new Label("💭  " + item.getPersonalNote());
                noteLbl.getStyleClass().add("detail-note");
                noteLbl.setWrapText(true);
                extraSection.getChildren().addAll(noteHead, noteLbl);
            }
        }

        // Added date
        
        Label dateLbl = new Label("Added " + (item.getAddedDate() != null ? item.getAddedDate().toString() : "—"));
        dateLbl.getStyleClass().add("detail-date");

        rightPane.getChildren().addAll(titleLbl, genreFlow, subFlow, vibeFlow, new Separator(), descSection, extraSection, dateLbl);
        scroll.setContent(rightPane);

        root.setLeft(leftPane);
        root.setCenter(scroll);

        Scene scene = new Scene(root, 800, 560);
        scene.getStylesheets().add(getClass().getResource("/css/" + controller.getCurrentTheme() + ".css").toExternalForm());
        setScene(scene);
    }

    private VBox placeholderPoster(MediaItem item) {
    	
        VBox ph = new VBox();
        ph.setAlignment(Pos.CENTER);
        ph.setPrefSize(200, 280);
        String color = item.getGenres().isEmpty() ? "#1a1a2e" : item.getGenres().get(0).getColor() + "44";
        ph.setStyle("-fx-background-color: " + color + ";");
        Label icon = new Label(item.getMediaType() == MediaItem.MediaType.FILM ? "🎬" : "📺");
        icon.setStyle("-fx-font-size: 56;");
        ph.getChildren().add(icon);
        return ph;
    }

    private Label sectionHead(String text) {
    	
        Label l = new Label(text);
        l.getStyleClass().add("detail-section-head");
        return l;
    }
}
