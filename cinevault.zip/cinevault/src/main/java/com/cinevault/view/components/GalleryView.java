package com.cinevault.view.components;

import com.cinevault.controller.MainController;
import com.cinevault.model.MediaItem;
import javafx.animation.*;
import javafx.collections.ListChangeListener;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.*;
import javafx.util.Duration;

public class GalleryView {

    private final ScrollPane scrollPane;
    private final TilePane tilePane;
    private final MainController controller;
    private final StackPane wrapper;

    public GalleryView(MainController controller) {
        this.controller = controller;

        tilePane = new TilePane();
        tilePane.getStyleClass().add("gallery-tile-pane");
        tilePane.setHgap(16);
        tilePane.setVgap(16);
        tilePane.setPadding(new Insets(16));
        tilePane.setPrefTileWidth(200);
        tilePane.setPrefTileHeight(300);
        tilePane.setTileAlignment(Pos.TOP_LEFT);

        scrollPane = new ScrollPane(tilePane);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(false);
        scrollPane.getStyleClass().add("gallery-scroll");
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        wrapper = new StackPane(scrollPane);
        wrapper.getStyleClass().add("gallery-wrapper");

        // Listen for filtered list changes
        
        controller.getFilteredItems().addListener((ListChangeListener<MediaItem>) c -> refreshGallery());
        refreshGallery();
    }

    private void refreshGallery() {
    	
        tilePane.getChildren().clear();

        if (controller.getFilteredItems().isEmpty()) {
        	
            Label empty = new Label("No results found\n\nTry changing the filters or adding more media.");
            empty.getStyleClass().add("empty-label");
            empty.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
            StackPane emptyPane = new StackPane(empty);
            emptyPane.setAlignment(Pos.CENTER);
            emptyPane.setPrefSize(600, 300);
            tilePane.getChildren().add(emptyPane);
            return;
        }

        int delay = 0;
        
        for (MediaItem item : controller.getFilteredItems()) {
           
        	MediaCard card = new MediaCard(item, controller);
            card.getNode().setOpacity(0);
            tilePane.getChildren().add(card.getNode());

            // Staggered fade-in animation
            
            FadeTransition fade = new FadeTransition(Duration.millis(300), card.getNode());
            fade.setFromValue(0);
            fade.setToValue(1);
            fade.setDelay(Duration.millis(delay));

            TranslateTransition slide = new TranslateTransition(Duration.millis(300), card.getNode());
            slide.setFromY(15);
            slide.setToY(0);
            slide.setDelay(Duration.millis(delay));

            ParallelTransition pt = new ParallelTransition(fade, slide);
            pt.play();

            delay += 30;
            
            if (delay > 500) {
            	
            	delay = 500; // cap
            }
        }
    }

    public StackPane getNode() {
    	
    	return wrapper; 
    }
}
