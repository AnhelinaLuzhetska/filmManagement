package com.cinevault.view.components;

import com.cinevault.controller.MainController;
import com.cinevault.model.Genre;
import com.cinevault.model.MediaItem;
import com.cinevault.model.Vibe;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class FilterSidebar {

    private final VBox node;
    private final MainController controller;
    private final List<CheckBox> genreCheckboxes = new ArrayList<>();
    private final List<CheckBox> vibeCheckboxes = new ArrayList<>();
    private VBox subgenreBox;
    
    private void updateSubgenres() {
    	
        subgenreBox.getChildren().clear();
        Set<String> available = new LinkedHashSet<>();
        
        for (CheckBox cb : genreCheckboxes) {
        	
            if (cb.isSelected()) {
            	
            	available.addAll(((Genre) cb.getUserData()).getSubGenres());
            }
        }
        controller.getFilterCriteria().getSubGenres().retainAll(available);

        for (String sub : available) {
        	
            CheckBox scb = new CheckBox(sub);
            scb.getStyleClass().add("subgenre-checkbox");
            scb.setSelected(controller.getFilterCriteria().getSubGenres().contains(sub));
            scb.selectedProperty().addListener((obs, old, newVal) -> {
               
            	if (newVal) {
            		
            		controller.getFilterCriteria().getSubGenres().add(sub);
            	
            	} else {
            		
            		controller.getFilterCriteria().getSubGenres().remove(sub);
            	}
                controller.applyFilters();
           
            });
            
            subgenreBox.getChildren().add(scb);
        }
    }

    public FilterSidebar(MainController controller) {
    	
        this.controller = controller;
        node = new VBox(0);
        node.getStyleClass().add("filter-sidebar");
        node.setPrefWidth(220);
        node.setPadding(new Insets(16, 0, 16, 0));

        ScrollPane scroll = new ScrollPane();
        scroll.setFitToWidth(true);
        scroll.getStyleClass().add("sidebar-scroll");
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        VBox content = new VBox(4);
        content.setPadding(new Insets(0, 12, 0, 12));

        // Title
        
        Label title = new Label("FILTERS");
        title.getStyleClass().add("sidebar-section-title");
        VBox.setMargin(title, new Insets(0, 0, 8, 4));

        // Reset button
        
        Button resetBtn = new Button("↺ Filter reset");
        resetBtn.getStyleClass().add("reset-btn");
        resetBtn.setMaxWidth(Double.MAX_VALUE);
        resetBtn.setOnAction(e -> resetFilters());

        content.getChildren().addAll(title, resetBtn, makeDivider());

        // Status filter
        
        content.getChildren().add(sectionLabel("STATE"));
        ToggleGroup statusGroup = new ToggleGroup();
        RadioButton all = radioBtn("All", null, statusGroup);
        RadioButton visti = radioBtn("Seen", MediaItem.WatchStatus.SEEN, statusGroup);
        RadioButton nonVisti = radioBtn("Must-see", MediaItem.WatchStatus.MUST_SEE, statusGroup);
        all.setSelected(true);
        statusGroup.selectedToggleProperty().addListener((obs, old, newToggle) -> {
           
        	if (newToggle != null) {
        		
                controller.getFilterCriteria().setWatchStatus((MediaItem.WatchStatus) newToggle.getUserData());
                controller.applyFilters();
            }
        });
        content.getChildren().addAll(all, visti, nonVisti, makeDivider());

        // Media type filter
       
        content.getChildren().add(sectionLabel("TYPE"));
        ToggleGroup typeGroup = new ToggleGroup();
        RadioButton allType = radioBtn("All", null, typeGroup);
        RadioButton films = radioBtn("🎬  Film", MediaItem.MediaType.FILM, typeGroup);
        RadioButton series = radioBtn("📺  TV Series", MediaItem.MediaType.TV_SERIES, typeGroup);
        allType.setSelected(true);
        typeGroup.selectedToggleProperty().addListener((obs, old, newToggle) -> {
           
        	if (newToggle != null) {
        		
                controller.getFilterCriteria().setMediaType((MediaItem.MediaType) newToggle.getUserData());
                controller.applyFilters();
            }
        });
        content.getChildren().addAll(allType, films, series, makeDivider());

        // Genre filter 
        
        content.getChildren().add(sectionLabel("GENRES"));
       
        for (Genre genre : Genre.values()) {
        	
            CheckBox cb = new CheckBox(genre.getDisplayName());
            cb.getStyleClass().add("genre-checkbox");
           
            // Color dot
            
            Rectangle dot = new Rectangle(10, 10, Color.web(genre.getColor()));
            dot.setArcWidth(4); dot.setArcHeight(4);
            cb.setGraphic(dot);
            genreCheckboxes.add(cb);
            cb.setUserData(genre);
            cb.selectedProperty().addListener((obs, old, newVal) -> {
               
            	if (newVal) {
            		
            		controller.getFilterCriteria().getGenres().add(genre);
            
            	} else {
            		
            		controller.getFilterCriteria().getGenres().remove(genre);
            	}
            	
                controller.applyFilters();
                updateSubgenres();
            });
            
            content.getChildren().add(cb);
        }
        
        content.getChildren().add(makeDivider());

        // SubGenre (dynamic)
        
        content.getChildren().add(sectionLabel("SUBGENRES"));
        subgenreBox = new VBox(2);
        content.getChildren().add(subgenreBox);
        content.getChildren().add(makeDivider());

        //  Vibe filter 
        
        content.getChildren().add(sectionLabel("VIBE"));
       
        for (String vibe : Vibe.ALL_VIBES) {
        	
            CheckBox cb = new CheckBox(vibe);
            cb.getStyleClass().add("vibe-checkbox");
            vibeCheckboxes.add(cb);
            cb.selectedProperty().addListener((obs, old, newVal) -> {
              
            	if (newVal) {
            		
            		controller.getFilterCriteria().getVibes().add(vibe);
           
            	} else {
            		
            		controller.getFilterCriteria().getVibes().remove(vibe);
            	}
            	
                controller.applyFilters();
            });
            
            content.getChildren().add(cb);
        }
        
        content.getChildren().add(makeDivider());

        //  Min rating 
        
        content.getChildren().add(sectionLabel("MINIMUM RATE"));
        Slider ratingSlider = new Slider(0, 10, 0);
        ratingSlider.setShowTickLabels(true);
        ratingSlider.setShowTickMarks(true);
        ratingSlider.setMajorTickUnit(2);
        ratingSlider.setSnapToTicks(false);
        ratingSlider.getStyleClass().add("rating-slider");
        Label ratingVal = new Label("0.0");
        ratingVal.getStyleClass().add("slider-value-label");
        ratingSlider.valueProperty().addListener((obs, old, newVal) -> {
            ratingVal.setText(String.format("%.1f", newVal.doubleValue()));
            controller.getFilterCriteria().setMinRating(newVal.doubleValue());
            controller.applyFilters();
        });
        content.getChildren().addAll(ratingSlider, ratingVal);

        scroll.setContent(content);
        node.getChildren().add(scroll);
        VBox.setVgrow(scroll, Priority.ALWAYS);
    }



    private void resetFilters() {
    	
        controller.resetFilters();
        genreCheckboxes.forEach(cb -> cb.setSelected(false));
        vibeCheckboxes.forEach(cb -> cb.setSelected(false));
        subgenreBox.getChildren().clear();
    }

    private Label sectionLabel(String text) {
    	
        Label l = new Label(text);
        l.getStyleClass().add("sidebar-section-label");
        VBox.setMargin(l, new Insets(10, 0, 4, 0));
        return l;
    }

    private RadioButton radioBtn(String text, Object userData, ToggleGroup group) {
      
    	RadioButton rb = new RadioButton(text);
        rb.setToggleGroup(group);
        rb.setUserData(userData);
        rb.getStyleClass().add("filter-radio");
        return rb;
    }

    private Separator makeDivider() {
    	
        Separator s = new Separator();
        s.getStyleClass().add("sidebar-divider");
        VBox.setMargin(s, new Insets(8, 0, 4, 0));
        return s;
    }

    public VBox getNode() { 
    	
    	return node; 
    }
}
