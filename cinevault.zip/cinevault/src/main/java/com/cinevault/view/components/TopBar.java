package com.cinevault.view.components;

import com.cinevault.controller.MainController;
import com.cinevault.model.MediaItem;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;

public class TopBar {

    private final HBox node;
    private Runnable onAddClicked;
    private Runnable onThemeToggle;

    public TopBar(MainController controller) {
    	
        node = new HBox(16);
        node.getStyleClass().add("top-bar");
        node.setAlignment(Pos.CENTER_LEFT);
        node.setPadding(new Insets(14, 20, 14, 20));

        // Logo
        
        Label logo = new Label("⬡ CINEVAULT ⬡");
        logo.getStyleClass().add("app-logo");

        // Stats
        
        Label statsLabel = new Label();
        statsLabel.getStyleClass().add("stats-label");
        updateStats(statsLabel, controller);
        controller.getAllItems().addListener((javafx.collections.ListChangeListener<MediaItem>) c -> updateStats(statsLabel, controller));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // Search
        
        TextField searchField = new TextField();
        searchField.setPromptText("🔍  Find media...");
        searchField.getStyleClass().add("search-field");
        searchField.setPrefWidth(240);
        searchField.textProperty().addListener((obs, old, newVal) -> {
            controller.getFilterCriteria().setSearchText(newVal);
            controller.applyFilters();
        });

        // Theme toggle
        
        Button themeBtn = new Button("☀ / ☾");
        themeBtn.getStyleClass().add("theme-toggle-btn");
        themeBtn.setOnAction(e -> { 
        	
        	if (onThemeToggle != null) {
        		
        		onThemeToggle.run();
        	}
        	
        });

        // Add button
        
        Button addBtn = new Button("＋ ADD");
        addBtn.getStyleClass().add("add-btn");
      
        addBtn.setOnAction(e -> { 
        	
        	if (onAddClicked != null) {
        		
        		onAddClicked.run();
        	}
        	
        });

        node.getChildren().addAll(logo, statsLabel, spacer, searchField, themeBtn, addBtn);
    }

    private void updateStats(Label label, MainController ctrl) {
    	
        long seen = ctrl.countByStatus(MediaItem.WatchStatus.SEEN);
        long mustSee = ctrl.countByStatus(MediaItem.WatchStatus.MUST_SEE);
        label.setText(String.format("   %d seen  ·   %d must-see", seen, mustSee));
    }

    public void setOnAddClicked(Runnable r) { 
    	
    	this.onAddClicked = r;
    }
    
    public void setOnThemeToggle(Runnable r) { 
    	
    	this.onThemeToggle = r; 
    }
    
    public HBox getNode() { 
    	
    	return node; 
    }
}
