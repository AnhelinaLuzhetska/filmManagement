package com.cinevault.controller;

import com.cinevault.data.DataStore;
import com.cinevault.model.FilterCriteria;
import com.cinevault.model.MediaItem;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.stage.Stage;

import java.util.function.Consumer;

public class MainController {

    private final DataStore dataStore = DataStore.getInstance();
    private final FilterCriteria filterCriteria = new FilterCriteria();
    private final FilteredList<MediaItem> filteredItems;
    private Stage stage;
    private Consumer<MediaItem> onEditRequest;
    private Consumer<MediaItem> onDetailRequest;
    private String currentTheme = "cyberpunk";

    public MainController() {
    	
        filteredItems = new FilteredList<>(dataStore.getItems(), item -> filterCriteria.matches(item));
    }

    public void setStage(Stage stage) { 
    	
    	this.stage = stage;
    	
    }
    
    public Stage getStage() { 
    	
    	return stage; 
    	
    }

    public ObservableList<MediaItem> getAllItems() { 
    	
    	return dataStore.getItems(); 
    	
    }
    
    public FilteredList<MediaItem> getFilteredItems() { 
    	
    	return filteredItems; 
    	
    }
    
    public FilterCriteria getFilterCriteria() { 
    	
    	return filterCriteria; 
    	
    }

    public void applyFilters() {
    	
        filteredItems.setPredicate(item -> filterCriteria.matches(item));
    }

    public void resetFilters() {
    	
        filterCriteria.reset();
        applyFilters();
    }

    public void addItem(MediaItem item) {
    	
        dataStore.add(item);
        
    }

    public void updateItem(MediaItem item) {
    	
        dataStore.update(item);
        applyFilters();
    }

    public void removeItem(MediaItem item) {
    	
        dataStore.remove(item);
       
    }

    public void setOnEditRequest(Consumer<MediaItem> handler) { 
    	
    	this.onEditRequest = handler; 
    	
    }
    
    public void setOnDetailRequest(Consumer<MediaItem> handler) { 
    	
    	this.onDetailRequest = handler; 
    	
    }

    public void requestEdit(MediaItem item) {
    	
        if (onEditRequest != null) {
        	
        	onEditRequest.accept(item);
        }
    }

    public void requestDetail(MediaItem item) {
    	
        if (onDetailRequest != null) {
        	
        	onDetailRequest.accept(item);
        }
    }

    public String getCurrentTheme() { 
    	
    	return currentTheme; 
    	
    }

    public void toggleTheme(javafx.scene.Scene scene) {
    	
        scene.getStylesheets().clear();
        
        if ("cyberpunk".equals(currentTheme)) {
        	
            currentTheme = "light";
            scene.getStylesheets().add(getClass().getResource("/css/light.css").toExternalForm());
        
        } else {
        	
            currentTheme = "cyberpunk";
            scene.getStylesheets().add(getClass().getResource("/css/cyberpunk.css").toExternalForm());
        }
    }

    public long countByStatus(MediaItem.WatchStatus status) {
    	
        return dataStore.getItems().stream().filter(i -> i.getWatchStatus() == status).count();
    }
}
