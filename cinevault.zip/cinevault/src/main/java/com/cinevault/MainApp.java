package com.cinevault;

import com.cinevault.controller.MainController;
import com.cinevault.view.MainView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class MainApp extends Application {

    @Override
    
    public void start(Stage primaryStage) {
    	
        MainController controller = new MainController();
        MainView mainView = new MainView(controller);

        Scene scene = new Scene(mainView.getRoot(), 1400, 900);
        scene.getStylesheets().add(getClass().getResource("/css/cyberpunk.css").toExternalForm());

        primaryStage.setTitle("⬡ CINEVAULT ⬡");
        primaryStage.setScene(scene);
        primaryStage.setMinWidth(1000);
        primaryStage.setMinHeight(700);
        primaryStage.show();

        controller.setStage(primaryStage);
    }

    public static void main(String[] args) {
    	
        launch(args);
    }
}
