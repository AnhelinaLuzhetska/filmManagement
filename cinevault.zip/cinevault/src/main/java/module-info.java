module com.cinevault {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires javafx.base;
    requires java.desktop;

    opens com.cinevault to javafx.fxml;
    opens com.cinevault.model to javafx.base;
    opens com.cinevault.controller to javafx.fxml;
    opens com.cinevault.view to javafx.fxml;
    opens com.cinevault.view.components to javafx.fxml;

    exports com.cinevault;
    exports com.cinevault.model;
    exports com.cinevault.controller;
    exports com.cinevault.view;
    exports com.cinevault.view.components;
}
