# ⬡ CINEVAULT — Gestione Film & Serie TV
### Interfaccia Cyberpunk / Synthwave in JavaFX

---

## 📁 STRUTTURA DEL PROGETTO

```
cinevault/
├── pom.xml                                          ← Build Maven
└── src/
    └── main/
        ├── java/
        │   ├── module-info.java                     ← Modulo JavaFX
        │   └── com/cinevault/
        │       ├── MainApp.java                     ← Entry point (Application)
        │       │
        │       ├── model/                           ← DATA MODEL
        │       │   ├── MediaItem.java               ← Entità principale (Film/Serie)
        │       │   ├── Genre.java                   ← Enum generi con colori e sottogeneri
        │       │   ├── Vibe.java                    ← Lista vibe disponibili
        │       │   └── FilterCriteria.java          ← Oggetto filtri attivi
        │       │
        │       ├── data/                            ← PERSISTENCE
        │       │   └── DataStore.java               ← Salvataggio JSON in ~/.cinevault/
        │       │
        │       ├── controller/                      ← CONTROLLER
        │       │   └── MainController.java          ← Logica app, filtri, CRUD
        │       │
        │       └── view/                            ← VIEW
        │           ├── MainView.java                ← Layout radice (BorderPane)
        │           ├── MediaDetailModal.java        ← Modale dettaglio media
        │           └── components/
        │               ├── TopBar.java              ← Barra superiore (logo, search, add)
        │               ├── FilterSidebar.java       ← Sidebar filtri dinamici
        │               ├── GalleryView.java         ← Griglia card con animazioni
        │               ├── MediaCard.java           ← Singola card con hover/glow
        │               └── MediaFormDialog.java     ← Form aggiungi/modifica
        │
        └── resources/
            └── css/
                ├── cyberpunk.css                    ← Tema Dark Neon (default)
                └── light.css                        ← Tema chiaro
```

---

## 🚀 COME AVVIARE

### Prerequisiti
- **Java 21+** (JDK con JavaFX incluso o separato)
- **Maven 3.8+**

### Avvio rapido
```bash
cd cinevault
mvn javafx:run
```

### Build JAR eseguibile
```bash
mvn package
# Il fat-jar sarà in: target/cinevault-1.0.0.jar
```

> **Nota:** Il fat-jar potrebbe non funzionare con JavaFX a causa del sistema di moduli.
> Si consiglia sempre `mvn javafx:run` oppure un launcher custom (script `.bat` / `.sh`).

### Script launcher (Windows)
```bat
@echo off
java --module-path "%PATH_TO_FX%" --add-modules javafx.controls,javafx.fxml ^
     -cp target/cinevault-1.0.0.jar com.cinevault.MainApp
```

---

## 🎨 FUNZIONALITÀ

| Funzionalità | Dettaglio |
|---|---|
| **Aggiunta media** | Film o Serie TV con foto, generi, sottogeneri, vibe, stato |
| **Galleria** | Griglia con card colorate in base al genere + animazioni hover/glow |
| **Filtri** | Sidebar: Stato, Tipo, Genere, Sottogenere, Vibe, Voto minimo |
| **Ricerca** | Ricerca live per titolo |
| **Sottogeneri dinamici** | Compaiono solo se il genere padre è selezionato |
| **Dettaglio** | Modale con poster, rating a stelle, recensione |
| **Tema** | Switch Cyberpunk ↔ Light con bottone in top bar |
| **Persistenza** | Salvataggio automatico JSON in `~/.cinevault/data.json` |
| **Animazioni** | Fade+slide staggered sulle card, scale+glow su hover |

---

## 🎭 GENERI SUPPORTATI (23)

Ogni genere ha un colore associato che determina il bordo e il gradiente delle card:

| Genere | Colore |
|---|---|
| Action | 🔴 Red `#FF2020` |
| Adventure | 🟠 Orange `#FF8C00` |
| Comedy | 🟡 Yellow `#FFD700` |
| Drama | 🔵 Dark Blue `#1A3A6B` |
| Horror | ⬛ Black `#111111` |
| Thriller | 🟥 Crimson `#8B0000` |
| Mystery | 🟣 Purple `#6A0DAD` |
| Crime | ⬜ Dark Gray `#3D3D3D` |
| Romance | 🩷 Pink `#FF69B4` |
| Sci-Fi | 🩵 Cyan `#00CED1` |
| Fantasy | 💚 Emerald `#00A86B` |
| Apocalypse | 🟫 Dusty Brown `#8B7355` |
| Dystopian | 🔵 Neon Blue `#0047AB` |
| Survival | 🫒 Olive `#6B8E23` |
| Psychological | 🟣 Deep Violet `#4B0082` |
| Slice of Life | 🟤 Beige `#D2C9A3` |
| Historical | 🟤 Sepia `#8B6914` |
| War | 🟢 Military Green `#355E3B` |
| Western | 🟡 Sand `#C19A6B` |
| Noir | ⬛ Charcoal `#36454F` |
| Musical | 🏅 Gold `#FFD700` |
| Documentary | ⬜ White `#E8E8E8` |
| Animation | 🌈 Multicolor `#FF6EC7` |

---

## 💾 FORMATO DATI

I dati vengono salvati in `~/.cinevault/data.json` (scritto senza librerie esterne):

```json
[
  {
    "id": "uuid-...",
    "mediaType": "FILM",
    "title": "Blade Runner 2049",
    "description": "Un replicante...",
    "photoPath": "/home/user/posters/br2049.jpg",
    "watchStatus": "VISTO",
    "genres": ["SCI_FI", "NOIR"],
    "subGenres": ["cyberpunk", "neo-noir thriller"],
    "vibes": ["neon-noir", "melancholic", "cerebral"],
    "rating": 9.5,
    "review": "Capolavoro visivo e narrativo.",
    "personalNote": "",
    "addedDate": "2025-01-15"
  }
]
```

---

## ⚙️ ARCHITETTURA MVC

```
Model ──────────────────────────────────────────────────────────
  MediaItem          → JavaFX Properties (Observable), dati film
  Genre              → Enum con colori e sottogeneri
  FilterCriteria     → Stato dei filtri attivi

Data ───────────────────────────────────────────────────────────
  DataStore          → Singleton, ObservableList, JSON I/O

Controller ─────────────────────────────────────────────────────
  MainController     → FilteredList, CRUD, callbacks view↔model

View ───────────────────────────────────────────────────────────
  MainView           → BorderPane radice, wiring componenti
  TopBar             → Logo, ricerca, pulsante aggiungi, tema
  FilterSidebar      → Filtri reattivi, sottogeneri dinamici
  GalleryView        → TilePane + animazioni staggered
  MediaCard          → Card con gradient genre, hover/glow
  MediaFormDialog    → Form aggiunta/modifica (Stage modale)
  MediaDetailModal   → Vista dettaglio completa (Stage modale)
```
